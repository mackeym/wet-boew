﻿$(function () {

    //Set height of left pane so things don't float over it
    if (!($("#dnn_LeftPane").hasClass("DNNEmptyPane"))) {
        $("#dnn_LeftPane").css('min-height', $("#dnn_ContentPane").height() + 'px');
    }

    //Set the Grid layout
    if ((!($("#dnn_RightPane").hasClass("DNNEmptyPane")) && ($("#dnn_LeftPane").hasClass("DNNEmptyPane"))) || (($("#dnn_RightPane").hasClass("DNNEmptyPane")) && !($("#dnn_LeftPane").hasClass("DNNEmptyPane")))) {
        $("#dnn_ContentPane").removeClass("span-6");
        $("#dnn_ContentPane").addClass("span-9");
    }
    else if (($("#dnn_RightPane").hasClass("DNNEmptyPane")) && ($("#dnn_LeftPane").hasClass("DNNEmptyPane"))) {
        $("#dnn_ContentPane").removeClass("span-6");
        $("#dnn_ContentPane").addClass("span-12");
    }

    if (!($("#dnn_MediaPane").hasClass("DNNEmptyPane"))) {
        $("#dnn_MediaPane").addClass("span-12");
    }


    //Resize images larger than content
    $('.DNNModuleContent').each(function () {
        var ModuleWidth = $(this).width();

        $(this).find('img').each(function () {
            if ($(this).width() > ModuleWidth) {
                $(this).css('width', '99%');
                $(this).css('height', 'auto');
            }
        });

    });

});
