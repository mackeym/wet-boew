﻿
Partial Class Portals__default_Skins_CLF3_SkinObjects_PageFormat_EndPageFormat
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

End Class
