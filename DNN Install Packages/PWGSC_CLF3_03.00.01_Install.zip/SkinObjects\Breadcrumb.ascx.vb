﻿
Partial Class Portals__default_Skins_CLF_Skin_Skin_Objects_Breadcrumb
    Inherits DotNetNuke.UI.Skins.SkinObjectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            'Alter the Query String if another language
            Dim TabString As String = "TabName"
            Dim LangController As New LocaleController
            Dim ThisLocale As String = System.Globalization.CultureInfo.CurrentUICulture.Name
            If LangController.GetDefaultLocale(PortalSettings.ActiveTab.PortalID).Code <> ThisLocale Then
                TabString = "ISNULL((SELECT [SettingValue] FROM [TabSettings] WHERE SettingName = 'PageTitle" & ThisLocale & "' AND TabID = TX.TabID), TX.TabName) AS 'TabName'"
            End If

            'Start of the string
            Dim TC As New DotNetNuke.Entities.Tabs.TabController
            lblNav.Text = Localization.GetString("SKINBreadLink", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
            lblNav.Text = lblNav.Text.Replace("[LINK]", "'http://" & PortalSettings.PortalAlias.HTTPAlias & TC.GetTab(PortalSettings.HomeTabId, PortalSettings.PortalId, True).TabPath.ToLower.Replace("//", "/") & ".aspx'")

            Dim inner As String = ""

            'This gets the new breadcrumbs, and while we're doing the query, we grab info for the metadata
            If PortalSettings.ActiveTab.TabID <> PortalSettings.HomeTabId Then

                Using connection As New SqlConnection(System.Configuration.ConfigurationSettings.AppSettings("SiteSqlServer").ToString)

                    Dim command As New SqlCommand
                    command.CommandText = "SELECT DISTINCT " & TabString & ", Title, TabOrder, TabPath, TabID, ParentId FROM [Tabs] TX " & _
                                          "WHERE ((TabPath = LEFT((SELECT T.TabPath FROM Tabs T WHERE T.TabID = @TabID),LEN(TabPath)) AND TabPath <> '//' AND CHARINDEX(LEFT((SELECT T.TabPath FROM Tabs T WHERE T.TabID = @TabID),LEN(TabPath)) + '//',(SELECT T.TabPath FROM Tabs T WHERE T.TabID = @TabID)) > 0) OR TabID = @TabID) AND PortalID = @PortalID ORDER BY TabPath"
                    command.Parameters.AddWithValue("@TabID", PortalSettings.ActiveTab.TabID)
                    command.Parameters.AddWithValue("@PortalID", PortalSettings.PortalId)
                    command.Connection = connection

                    Try

                        command.Connection.Open()
                        Dim reader As SqlDataReader = command.ExecuteReader
                        While reader.Read

                            If reader.Item("TabID").ToString <> PortalSettings.HomeTabId Then
                                If reader.Item("TabID").ToString = PortalSettings.ActiveTab.TabID Then
                                    inner = inner & "<li>" & reader.Item("TabName").ToString & "</li>"
                                Else
                                    Dim BreadLink As String = Localization.GetString("SKINBreadTemplate", PortalSettings.ActiveTab.SkinPath + Localization.LocalResourceDirectory + "/" & System.IO.Path.GetFileName(Server.MapPath(PortalSettings.ActiveTab.SkinSrc)))
                                    BreadLink = BreadLink.Replace("[LINK]", "'http://" & PortalSettings.PortalAlias.HTTPAlias & reader.Item("TabPath").ToString.ToLower.Replace("//", "/") & ".aspx'")
                                    BreadLink = BreadLink.Replace("[NAME]", reader.Item("TabName").ToString)
                                    inner = inner & BreadLink

                                End If
                            End If

                        End While

                    Finally
                        command.Connection.Close()
                    End Try

                End Using

            End If

            lblNav.Text = "<ol>" & lblNav.Text & inner & "</ol>"
        Catch ex As Exception
            If PortalSettings.UserInfo.IsSuperUser Then Response.Write("Breadcrumb Error: " & ex.Message)
        End Try
    End Sub



End Class
